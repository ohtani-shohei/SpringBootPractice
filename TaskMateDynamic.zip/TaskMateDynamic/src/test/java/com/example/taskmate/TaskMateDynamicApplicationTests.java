package com.example.taskmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskMateDynamicApplicationTests {

	@Test
	void contextLoads() {
	}

}
