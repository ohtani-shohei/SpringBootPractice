package com.example.taskmate.entity;

import lombok.Data;

@Data
public class Memo {
	
	private Integer memoId;
	private Integer taskId;
	private String memo;

}
