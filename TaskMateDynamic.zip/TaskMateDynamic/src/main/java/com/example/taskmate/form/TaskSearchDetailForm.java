package com.example.taskmate.form;

import lombok.Data;

@Data
public class TaskSearchDetailForm {
	
	private Integer taskId;

}
