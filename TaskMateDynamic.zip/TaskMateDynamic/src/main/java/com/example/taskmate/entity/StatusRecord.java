package com.example.taskmate.entity;

import lombok.Data;

@Data
public class StatusRecord {
	private String statusCode;
	private String statusName;
}
